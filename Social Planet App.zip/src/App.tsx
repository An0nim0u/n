import React, { useState, useEffect } from 'react';
import { MessageCircle, Crown, Settings, User, ShoppingCart, Coins, Send, Home, Bell, Search, ArrowLeft, MoreVertical, Phone, Video, Users, Edit, Camera, Heart, Share2, Bookmark, Grid, List, Calendar, Plus, Lock, Globe, UserPlus, LogOut, Mic, Film, Gamepad2, X, Image as ImageIcon, Sparkles } from 'lucide-react';

// Simulador de servidor simple
class ServerSimulator {
  constructor() {
    this.connectedUsers = new Map();
    this.listeners = new Set();
    this.messageHistory = [];
  }

  connect(user) {
    this.connectedUsers.set(user.id, {
      ...user,
      connectedAt: Date.now(),
      isOnline: true
    });
    this.notifyListeners();
  }

  disconnect(userId) {
    if (this.connectedUsers.has(userId)) {
      this.connectedUsers.delete(userId);
      this.notifyListeners();
    }
  }

  getConnectedUsers() {
    return Array.from(this.connectedUsers.values());
  }

  addListener(callback) {
    this.listeners.add(callback);
  }

  removeListener(callback) {
    this.listeners.delete(callback);
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      callback(this.getConnectedUsers());
    });
  }

  sendMessage(message) {
    const fullMessage = {
      ...message,
      id: Date.now(),
      timestamp: new Date().toISOString()
    };
    this.messageHistory.push(fullMessage);
    this.notifyListeners();
    return fullMessage;
  }

  getMessages() {
    return this.messageHistory;
  }
}

const gameServer = new ServerSimulator();

function SocialPlanet() {
  const [currentPage, setCurrentPage] = useState('login');
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showUserActions, setShowUserActions] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [connectedUsers, setConnectedUsers] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [selectedChatUser, setSelectedChatUser] = useState(null);
  const [privateChats, setPrivateChats] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [currentProfileTab, setCurrentProfileTab] = useState('posts');
  const [viewingProfile, setViewingProfile] = useState(null);
  const [clubs, setClubs] = useState([
    {
      id: 1,
      name: 'Gamers Planet',
      description: 'Comunidad de jugadores apasionados',
      avatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=200&h=200&fit=crop',
      banner: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&h=300&fit=crop',
      members: 245,
      isPrivate: false,
      category: 'Gaming',
      createdBy: 1
    },
    {
      id: 2,
      name: 'Arte Digital',
      description: 'Creativos y artistas digitales',
      avatar: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=200&h=200&fit=crop',
      banner: 'https://images.unsplash.com/photo-1549887534-1541e9326642?w=800&h=300&fit=crop',
      members: 128,
      isPrivate: false,
      category: 'Arte',
      createdBy: 2
    },
    {
      id: 3,
      name: 'Desarrolladores',
      description: 'Programación y tecnología',
      avatar: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=200&h=200&fit=crop',
      banner: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=300&fit=crop',
      members: 367,
      isPrivate: true,
      category: 'Tech',
      createdBy: 1
    }
  ]);
  const [selectedClub, setSelectedClub] = useState(null);
  const [clubMessages, setClubMessages] = useState({});
  const [userClubs, setUserClubs] = useState([1]);
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [clubActiveFeature, setClubActiveFeature] = useState('chat');
  const [voiceConnected, setVoiceConnected] = useState(false);
  const [cinemaMovie, setCinemaMovie] = useState(null);
  const [roleplayScenario, setRoleplayScenario] = useState(null);
  const [showClubFeatures, setShowClubFeatures] = useState(false);
  const [postComments, setPostComments] = useState({});
  const [showCommentsFor, setShowCommentsFor] = useState(null);
  const [profileComments, setProfileComments] = useState({});
  
  const [user, setUser] = useState({
    id: Math.floor(Math.random() * 10000),
    name: 'User_123',
    email: 'moisesgood4@gmail.com',
    role: 'admin',
    qi: 150,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
    status: 'En línea',
    planetas: 500,
    frameId: null,
    ownedFrames: [],
    bio: 'Fundador de ProjectZ 🚀',
    posts: 0,
    followers: 0
  });

  const [userProfiles, setUserProfiles] = useState([
    {
      id: 2,
      name: 'GameMaster_X',
      email: 'gamer@example.com',
      role: 'user',
      qi: 180,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      bio: 'Experto en RPG y aventuras épicas.',
      posts: 45,
      followers: 230,
      suspended: false,
      planetas: 150,
      frameId: null,
      ownedFrames: []
    },
    {
      id: 3,
      name: 'ArtisticSoul',
      email: 'artist@example.com',
      role: 'user',
      qi: 140,
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
      bio: 'Creadora de arte digital y NFTs.',
      posts: 67,
      followers: 180,
      suspended: false,
      planetas: 200,
      frameId: null,
      ownedFrames: []
    }
  ]);

  const [posts, setPosts] = useState([
    {
      id: 1,
      userId: 2,
      userName: 'GameMaster_X',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      content: '¡Acabo de completar un nivel épico! 🎮✨',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      likes: 24,
      comments: 5
    },
    {
      id: 2,
      userId: 3,
      userName: 'ArtisticSoul',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
      content: 'Nuevo arte disponible en mi perfil 🎨🌟',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      likes: 42,
      comments: 8
    }
  ]);

  const shopFrames = [
    {
      id: 'cosmic',
      name: 'Marco Cósmico',
      description: 'Un marco que brilla con la energía de las estrellas',
      price: 100,
      rarity: 'común',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="cosmic-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#a855f7', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#cosmic-grad)" strokeWidth="4" opacity="0.8" />
          <circle cx="60" cy="60" r="54" fill="none" stroke="url(#cosmic-grad)" strokeWidth="2" opacity="0.4" />
        </svg>
      )
    },
    {
      id: 'fire',
      name: 'Marco de Fuego',
      description: 'Llamas ardientes rodean tu avatar',
      price: 150,
      rarity: 'raro',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none animate-pulse" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="fire-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#ef4444', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#f97316', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#fire-grad)" strokeWidth="5" />
          <path d="M 60 10 L 65 20 L 60 15 L 55 20 Z" fill="#ef4444" opacity="0.8" />
          <path d="M 110 60 L 100 65 L 105 60 L 100 55 Z" fill="#f97316" opacity="0.8" />
          <path d="M 60 110 L 65 100 L 60 105 L 55 100 Z" fill="#ef4444" opacity="0.8" />
          <path d="M 10 60 L 20 65 L 15 60 L 20 55 Z" fill="#f97316" opacity="0.8" />
        </svg>
      )
    },
    {
      id: 'legendary',
      name: 'Marco Legendario',
      description: 'Solo para los más elite del universo',
      price: 500,
      rarity: 'legendario',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none animate-pulse" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="legendary-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#fbbf24', stopOpacity: 1 }} />
              <stop offset="50%" style={{ stopColor: '#a855f7', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#fbbf24', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#legendary-grad)" strokeWidth="6" />
          <circle cx="60" cy="60" r="52" fill="none" stroke="#fbbf24" strokeWidth="2" opacity="0.5" />
          <polygon points="60,5 65,18 78,15 68,25 75,38 60,30 45,38 52,25 42,15 55,18" fill="#fbbf24" opacity="0.9" />
          <polygon points="60,115 65,102 78,105 68,95 75,82 60,90 45,82 52,95 42,105 55,102" fill="#fbbf24" opacity="0.9" />
        </svg>
      )
    },
    {
      id: 'neon',
      name: 'Marco Neón',
      description: 'Luces de neón futuristas',
      price: 200,
      rarity: 'raro',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="neon-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#06b6d4', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#ec4899', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#neon-grad)" strokeWidth="4" />
          <circle cx="60" cy="60" r="56" fill="none" stroke="#06b6d4" strokeWidth="1" opacity="0.6" />
          <circle cx="60" cy="60" r="54" fill="none" stroke="#ec4899" strokeWidth="1" opacity="0.6" />
        </svg>
      )
    },
    {
      id: 'diamond',
      name: 'Marco Diamante',
      description: 'Cristales brillantes de otro mundo',
      price: 300,
      rarity: 'épico',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="diamond-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#d1d5db', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#93c5fd', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#diamond-grad)" strokeWidth="5" />
          <polygon points="60,8 70,20 60,15 50,20" fill="#d1d5db" opacity="0.8" />
          <polygon points="112,60 100,70 105,60 100,50" fill="#93c5fd" opacity="0.8" />
          <polygon points="60,112 70,100 60,105 50,100" fill="#d1d5db" opacity="0.8" />
          <polygon points="8,60 20,70 15,60 20,50" fill="#93c5fd" opacity="0.8" />
        </svg>
      )
    },
    {
      id: 'galaxy',
      name: 'Marco Galáctico',
      description: 'La galaxia completa te rodea',
      price: 750,
      rarity: 'mítico',
      svg: (
        <svg className="absolute inset-0 w-full h-full pointer-events-none animate-pulse" viewBox="0 0 120 120">
          <defs>
            <linearGradient id="galaxy-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#7c3aed', stopOpacity: 1 }} />
              <stop offset="50%" style={{ stopColor: '#2563eb', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#db2777', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="58" fill="none" stroke="url(#galaxy-grad)" strokeWidth="6" />
          <circle cx="60" cy="60" r="52" fill="none" stroke="#7c3aed" strokeWidth="3" opacity="0.5" />
          <circle cx="30" cy="30" r="3" fill="#fff" opacity="0.8" />
          <circle cx="90" cy="30" r="2" fill="#fff" opacity="0.6" />
          <circle cx="90" cy="90" r="3" fill="#fff" opacity="0.8" />
          <circle cx="30" cy="90" r="2" fill="#fff" opacity="0.6" />
          <circle cx="60" cy="15" r="2" fill="#fbbf24" opacity="0.9" />
          <circle cx="105" cy="60" r="2" fill="#fbbf24" opacity="0.9" />
        </svg>
      )
    }
  ];

  const isAdmin = () => user.email === 'moisesgood4@gmail.com' && user.role === 'admin';

  const getQIColor = (qi) => {
    if (qi >= 200) return 'from-purple-500 to-pink-500';
    if (qi >= 150) return 'from-blue-500 to-cyan-500';
    if (qi >= 100) return 'from-green-500 to-emerald-500';
    return 'from-gray-500 to-slate-500';
  };

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'común': return 'text-gray-400';
      case 'raro': return 'text-blue-400';
      case 'épico': return 'text-purple-400';
      case 'legendario': return 'text-yellow-400';
      case 'mítico': return 'text-pink-400';
      default: return 'text-gray-400';
    }
  };

  const getTimeAgo = (timestamp) => {
    const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
    if (seconds < 60) return 'ahora';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
  };

  const renderAvatarWithFrame = (userObj, size = 'w-20 h-20') => {
    const currentFrame = userObj.frameId ? shopFrames.find(f => f.id === userObj.frameId) : null;
    
    return (
      <div className={`relative ${size}`}>
        <img 
          src={userObj.avatar} 
          alt={userObj.name} 
          className="w-full h-full rounded-full border-2 border-purple-500 object-cover"
        />
        {currentFrame && (
          <div className="absolute inset-0 pointer-events-none" style={{ margin: '-10%', width: '120%', height: '120%' }}>
            {currentFrame.svg}
          </div>
        )}
        {userObj.role === 'admin' && (
          <Crown className="absolute -top-1 -right-1 w-5 h-5 text-purple-400 drop-shadow-lg" />
        )}
        {userObj.role === 'moderator' && (
          <Crown className="absolute -top-1 -right-1 w-5 h-5 text-yellow-400 drop-shadow-lg" />
        )}
      </div>
    );
  };

  const buyFrame = (frameId) => {
    const frame = shopFrames.find(f => f.id === frameId);
    if (!frame) return;

    if (user.planetas < frame.price) {
      alert(`¡No tienes suficientes planetas! Necesitas ${frame.price} planetas.`);
      return;
    }

    if (user.ownedFrames.includes(frameId)) {
      alert('¡Ya tienes este marco!');
      return;
    }

    setUser(prev => ({
      ...prev,
      planetas: prev.planetas - frame.price,
      ownedFrames: [...prev.ownedFrames, frameId]
    }));

    alert(`¡Marco "${frame.name}" comprado exitosamente! 🎉`);
  };

  const equipFrame = (frameId) => {
    if (!user.ownedFrames.includes(frameId)) {
      alert('¡No tienes este marco!');
      return;
    }

    setUser(prev => ({
      ...prev,
      frameId: frameId
    }));

    alert('¡Marco equipado exitosamente!');
    setShowShop(false);
  };

  const unequipFrame = () => {
    setUser(prev => ({
      ...prev,
      frameId: null
    }));
    alert('Marco desequipado');
  };

  const claimDailyPlanetas = () => {
    const dailyAmount = Math.floor(Math.random() * 50) + 25;
    setUser(prev => ({
      ...prev,
      planetas: prev.planetas + dailyAmount
    }));
    alert(`¡Has recibido ${dailyAmount} planetas diarios! 🪐`);
  };

  const suspendUser = (userId) => {
    setUserProfiles(prev => prev.map(profile => 
      profile.id === userId ? { ...profile, suspended: true } : profile
    ));
    setShowUserActions(false);
    alert('Usuario suspendido exitosamente');
  };

  const makeUserModerator = (userId) => {
    setUserProfiles(prev => prev.map(profile => 
      profile.id === userId ? { ...profile, role: 'moderator' } : profile
    ));
    setShowUserActions(false);
    alert('Usuario promovido a moderador');
  };

  useEffect(() => {
    if (currentPage !== 'login') {
      gameServer.connect(user);

      const handleUsersUpdate = (users) => {
        setConnectedUsers(users.filter(u => u.id !== user.id));
      };

      gameServer.addListener(handleUsersUpdate);

      return () => {
        gameServer.removeListener(handleUsersUpdate);
        gameServer.disconnect(user.id);
      };
    }
  }, [currentPage, user]);

  useEffect(() => {
    if (currentPage !== 'login') {
      const simulateUsers = () => {
        const demoUsers = [
          {
            id: 1001,
            name: 'SpaceExplorer',
            email: 'explorer@space.com',
            role: 'user',
            qi: 165,
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
            status: 'En línea',
            planetas: 120,
            frameId: null,
            ownedFrames: []
          },
          {
            id: 1002,
            name: 'CosmicArtist',
            email: 'artist@cosmic.com',
            role: 'user',
            qi: 142,
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
            status: 'En línea',
            planetas: 80,
            frameId: null,
            ownedFrames: []
          },
          {
            id: 1003,
            name: 'QuantumHacker',
            email: 'quantum@hacker.com',
            role: 'moderator',
            qi: 195,
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
            status: 'En línea',
            planetas: 300,
            frameId: 'cosmic',
            ownedFrames: ['cosmic']
          }
        ];

        demoUsers.forEach((demoUser, index) => {
          setTimeout(() => {
            if (Math.random() > 0.3) {
              gameServer.connect(demoUser);
            }
          }, (index + 1) * 2000);
        });
      };

      const timer = setTimeout(simulateUsers, 3000);
      return () => clearTimeout(timer);
    }
  }, [currentPage, user.id]);

  const LoginScreen = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [username, setUsername] = useState('');

    const handleSubmit = (e) => {
      e.preventDefault();
      
      if (!acceptTerms) {
        alert('Debes aceptar los términos y condiciones');
        return;
      }

      if (!email || !password) {
        alert('Por favor completa todos los campos');
        return;
      }

      if (isRegisterMode) {
        if (password !== confirmPassword) {
          alert('Las contraseñas no coinciden');
          return;
        }
        if (!username) {
          alert('Por favor ingresa un nombre de usuario');
          return;
        }
      }

      const userId = Math.floor(Math.random() * 10000);
      const userName = isRegisterMode ? username : (email.split('@')[0] || 'Usuario');

      if (email === 'moisesgood4@gmail.com' && !isRegisterMode) {
        setUser({
          id: userId,
          name: 'Admin_' + userName,
          email: email,
          role: 'admin',
          qi: 200,
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
          status: 'En línea',
          planetas: 1000,
          frameId: null,
          ownedFrames: [],
          bio: 'Fundador de Social Planet 🚀',
          posts: 0,
          followers: 0
        });
      } else {
        setUser({
          id: userId,
          name: userName,
          email: email,
          role: 'user',
          qi: Math.floor(Math.random() * 100) + 100,
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
          status: 'En línea',
          planetas: Math.floor(Math.random() * 200) + 50,
          frameId: null,
          ownedFrames: [],
          bio: isRegisterMode ? '¡Nuevo miembro de Social Planet! 🌟' : '¡Nuevo en Social Planet! 🌟',
          posts: 0,
          followers: 0
        });
      }

      setCurrentPage('home');
      alert(isRegisterMode ? '¡Registro exitoso! Bienvenido a Social Planet! 🚀' : '¡Bienvenido de vuelta! 🚀');
    };

    return (
      <div className="min-h-screen bg-black flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-black to-blue-900/30"></div>
        
        {/* Partículas animadas de fondo */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-purple-400 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 2}s`,
                opacity: 0.3 + Math.random() * 0.3
              }}
            />
          ))}
        </div>

        <style>
          {`
            @keyframes float {
              0%, 100% { transform: translateY(0px) translateX(0px); }
              25% { transform: translateY(-20px) translateX(10px); }
              50% { transform: translateY(-40px) translateX(-10px); }
              75% { transform: translateY(-20px) translateX(5px); }
            }
          `}
        </style>
        
        <div className="relative z-10 w-full max-w-md mx-4">
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center border-4 border-purple-400/50 mx-auto mb-6 shadow-2xl shadow-purple-400/50 animate-pulse">
              <span className="text-4xl">🪐</span>
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-blue-600 bg-clip-text text-transparent mb-2">
              Social Planet
            </h1>
            <p className="text-purple-300/80 text-lg">
              {isRegisterMode ? 'Únete al universo' : 'Tu planeta social comienza aquí'}
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-900/20 to-black/80 backdrop-blur-sm rounded-2xl border border-purple-500/30 p-8 shadow-2xl shadow-purple-500/20">
            <div className="flex mb-6 bg-black/40 rounded-lg p-1">
              <button
                onClick={() => setIsRegisterMode(false)}
                className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                  !isRegisterMode
                    ? 'bg-gradient-to-r from-purple-500 to-blue-600 text-white'
                    : 'text-purple-300/60 hover:text-purple-300'
                }`}
              >
                Iniciar Sesión
              </button>
              <button
                onClick={() => setIsRegisterMode(true)}
                className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                  isRegisterMode
                    ? 'bg-gradient-to-r from-purple-500 to-blue-600 text-white'
                    : 'text-purple-300/60 hover:text-purple-300'
                }`}
              >
                Registrarse
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="space-y-4 mb-6">
                {isRegisterMode && (
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Nombre de usuario"
                    className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-4 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/50"
                    required={isRegisterMode}
                  />
                )}

                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={isRegisterMode ? "Tu correo electrónico" : "moisesgood4@gmail.com (admin) o tu email"}
                  className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-4 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/50"
                  required
                />

                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Contraseña (mínimo 6 caracteres)"
                  className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-4 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/50"
                  required
                  minLength={6}
                />

                {isRegisterMode && (
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirmar contraseña"
                    className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-4 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/50"
                    required={isRegisterMode}
                    minLength={6}
                  />
                )}
              </div>

              <div className="flex items-center space-x-3 mb-6">
                <input
                  type="checkbox"
                  id="terms"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="w-4 h-4 text-purple-500 bg-black border-purple-500 rounded focus:ring-purple-400"
                />
                <label htmlFor="terms" className="text-purple-300/80 text-sm">
                  Acepto los términos y condiciones
                </label>
              </div>

              <button
                type="submit"
                disabled={!acceptTerms}
                className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
                  acceptTerms
                    ? 'bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500 text-white shadow-lg shadow-purple-500/50 hover:shadow-purple-500/70 hover:scale-105'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                {isRegisterMode ? '🚀 Crear Cuenta' : '🚀 Entrar a Social Planet'}
              </button>
            </form>

            {!isRegisterMode && (
              <div className="mt-4 text-center text-purple-300/60 text-sm">
                💡 Usa <span className="text-purple-400 font-semibold">moisesgood4@gmail.com</span> para acceso de administrador
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const HomeScreen = () => {
    const [postContent, setPostContent] = useState('');
    const [postImage, setPostImage] = useState(null);
    const [commentInput, setCommentInput] = useState('');

    const handleImageUpload = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPostImage(reader.result);
        };
        reader.readAsDataURL(file);
      }
    };

    const handleCreatePost = () => {
      if (!postContent.trim() && !postImage) return;

      const newPost = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        userRole: user.role,
        userFrameId: user.frameId,
        content: postContent,
        image: postImage,
        timestamp: new Date().toISOString(),
        likes: 0,
        comments: 0
      };

      setPosts(prev => [newPost, ...prev]);
      setUser(prev => ({ ...prev, posts: prev.posts + 1 }));
      setPostContent('');
      setPostImage(null);
    };

    const handleAddComment = (postId) => {
      if (!commentInput.trim()) return;

      const newComment = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        content: commentInput,
        timestamp: new Date().toISOString()
      };

      setPostComments(prev => ({
        ...prev,
        [postId]: [...(prev[postId] || []), newComment]
      }));

      setPosts(prev => prev.map(p => 
        p.id === postId ? { ...p, comments: p.comments + 1 } : p
      ));

      setCommentInput('');
    };

    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="bg-gradient-to-b from-purple-900/20 to-black min-h-screen">
          <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-md border-b border-purple-500/30">
            <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
                Social Planet
              </h1>
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative text-purple-400 hover:text-purple-300"
                >
                  <Bell className="w-6 h-6" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <div className="flex items-center space-x-2">
                  <Coins className="w-5 h-5 text-yellow-400" />
                  <span className="text-yellow-400 font-bold">{user.planetas}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-2xl mx-auto px-4 py-4">
            <div className="bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl border border-purple-500/30 p-4">
              <div className="flex space-x-3">
                {renderAvatarWithFrame(user, 'w-12 h-12')}
                <div className="flex-1">
                  <textarea
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    placeholder="¿Qué está pasando?"
                    className="w-full bg-black/40 border border-purple-500/20 rounded-lg px-4 py-3 text-white placeholder-purple-300/40 focus:outline-none focus:border-purple-400 resize-none"
                    rows="3"
                  />
                  {postImage && (
                    <div className="relative mt-3">
                      <img src={postImage} alt="Preview" className="w-full rounded-lg max-h-64 object-cover" />
                      <button
                        onClick={() => setPostImage(null)}
                        className="absolute top-2 right-2 bg-black/80 hover:bg-red-600 p-2 rounded-full transition-colors"
                      >
                        <X className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  )}
                  <div className="flex justify-between items-center mt-3">
                    <label className="cursor-pointer text-purple-400 hover:text-purple-300 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <ImageIcon className="w-6 h-6" />
                    </label>
                    <button
                      onClick={handleCreatePost}
                      disabled={!postContent.trim() && !postImage}
                      className={`px-6 py-2 rounded-full font-semibold ${
                        (postContent.trim() || postImage)
                          ? 'bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 text-white'
                          : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      Publicar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-2xl mx-auto px-4 space-y-4">
            {posts.map(post => {
              const postUser = userProfiles.find(u => u.id === post.userId) || (post.userId === user.id ? user : null);
              const comments = postComments[post.id] || [];
              const isShowingComments = showCommentsFor === post.id;
              
              return (
                <div key={post.id} className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/20 hover:border-purple-500/40 transition-all">
                  <div className="p-6">
                    <div className="flex space-x-3">
                      <div className="flex-shrink-0">
                        {postUser && renderAvatarWithFrame(postUser, 'w-12 h-12')}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-white">{post.userName}</span>
                          {post.userRole === 'admin' && <Crown className="w-4 h-4 text-purple-400" />}
                          {post.userRole === 'moderator' && <Crown className="w-4 h-4 text-yellow-400" />}
                          <span className="text-purple-300/60 text-sm">· {getTimeAgo(post.timestamp)}</span>
                        </div>
                        <p className="text-white mt-2 text-lg">{post.content}</p>
                        {post.image && (
                          <img src={post.image} alt="" className="mt-3 rounded-lg w-full max-h-96 object-cover" />
                        )}
                        <div className="flex items-center space-x-6 mt-4 text-purple-300/60">
                          <button className="flex items-center space-x-2 hover:text-red-400 transition-colors">
                            <Heart className="w-5 h-5" />
                            <span>{post.likes}</span>
                          </button>
                          <button 
                            onClick={() => setShowCommentsFor(isShowingComments ? null : post.id)}
                            className="flex items-center space-x-2 hover:text-blue-400 transition-colors"
                          >
                            <MessageCircle className="w-5 h-5" />
                            <span>{post.comments}</span>
                          </button>
                          <button className="flex items-center space-x-2 hover:text-green-400 transition-colors">
                            <Share2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Sección de comentarios */}
                  {isShowingComments && (
                    <div className="border-t border-purple-500/20 p-4 bg-black/20">
                      {comments.length > 0 && (
                        <div className="space-y-3 mb-4">
                          {comments.map(comment => (
                            <div key={comment.id} className="flex space-x-2">
                              <img src={comment.userAvatar} className="w-8 h-8 rounded-full" alt="" />
                              <div className="flex-1 bg-purple-900/20 rounded-lg p-3">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-semibold text-white text-sm">{comment.userName}</span>
                                  <span className="text-purple-300/40 text-xs">{getTimeAgo(comment.timestamp)}</span>
                                </div>
                                <p className="text-white text-sm">{comment.content}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      <div className="flex space-x-2">
                        <img src={user.avatar} className="w-8 h-8 rounded-full" alt="" />
                        <input
                          type="text"
                          value={commentInput}
                          onChange={(e) => setCommentInput(e.target.value)}
                          placeholder="Escribe un comentario..."
                          className="flex-1 bg-purple-900/20 border border-purple-500/30 rounded-full px-4 py-2 text-white text-sm placeholder-purple-300/60 focus:outline-none focus:border-purple-400"
                          onKeyPress={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                        />
                        <button
                          onClick={() => handleAddComment(post.id)}
                          className="text-purple-400 hover:text-purple-300"
                        >
                          <Send className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const ChatsScreen = () => {
    const [messageInput, setMessageInput] = useState('');
    
    const allUsers = [...connectedUsers, ...userProfiles].filter((chatUser, index, self) => 
      index === self.findIndex(u => u.id === chatUser.id)
    );

    const getChatMessages = (chatUserId) => {
      const chatKey = [user.id, chatUserId].sort().join('-');
      return privateChats[chatKey] || [];
    };

    const getLastMessage = (chatUserId) => {
      const messages = getChatMessages(chatUserId);
      return messages.length > 0 ? messages[messages.length - 1] : null;
    };

    const handleSendMessage = () => {
      if (!messageInput.trim() || !selectedChatUser) return;
      
      const message = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        content: messageInput,
        timestamp: new Date().toISOString()
      };

      const chatKey = [user.id, selectedChatUser.id].sort().join('-');
      setPrivateChats(prev => ({
        ...prev,
        [chatKey]: [...(prev[chatKey] || []), message]
      }));
      
      setMessageInput('');
    };

    if (selectedChatUser) {
      const messages = getChatMessages(selectedChatUser.id);
      
      return (
        <div className="min-h-screen bg-black text-white pb-20 flex flex-col">
          <div className="sticky top-0 z-30 bg-gradient-to-r from-purple-900/90 to-black/90 backdrop-blur-md border-b border-purple-500/30">
            <div className="px-4 py-3 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <button onClick={() => setSelectedChatUser(null)} className="text-purple-400 hover:text-purple-300">
                  <ArrowLeft className="w-6 h-6" />
                </button>
                {renderAvatarWithFrame(selectedChatUser, 'w-10 h-10')}
                <div>
                  <h2 className="font-semibold text-white">{selectedChatUser.name}</h2>
                  <p className="text-xs text-green-400">En línea</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button className="text-purple-400 hover:text-purple-300">
                  <Phone className="w-5 h-5" />
                </button>
                <button className="text-purple-400 hover:text-purple-300">
                  <Video className="w-5 h-5" />
                </button>
                <button className="text-purple-400 hover:text-purple-300">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 bg-gradient-to-b from-purple-900/10 to-black">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="text-6xl mb-4">💬</div>
                <p className="text-purple-300/60 text-lg">Inicia la conversación con {selectedChatUser.name}</p>
                <p className="text-purple-300/40 text-sm mt-2">Envía un mensaje para comenzar</p>
              </div>
            ) : (
              messages.map((msg, index) => {
                const isMe = msg.userId === user.id;
                const showAvatar = index === 0 || messages[index - 1].userId !== msg.userId;
                
                return (
                  <div key={msg.id} className={`flex items-end space-x-2 ${isMe ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className="flex-shrink-0 w-8">
                      {!isMe && showAvatar && (
                        <img src={msg.userAvatar} className="w-8 h-8 rounded-full" alt="" />
                      )}
                    </div>
                    <div className={`max-w-xs lg:max-w-md ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                      <div className={`px-4 py-2 rounded-2xl ${
                        isMe 
                          ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-br-sm' 
                          : 'bg-purple-900/40 text-white rounded-bl-sm'
                      }`}>
                        <p>{msg.content}</p>
                      </div>
                      <span className="text-xs text-purple-300/40 mt-1 px-2">{getTimeAgo(msg.timestamp)}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="sticky bottom-0 bg-black/90 backdrop-blur-md border-t border-purple-500/30 p-4">
            <div className="flex items-center space-x-3">
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Escribe un mensaje..."
                className="flex-1 bg-purple-900/20 border border-purple-500/30 rounded-full px-5 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-400/50"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                className={`p-3 rounded-full ${
                  messageInput.trim()
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="bg-gradient-to-b from-purple-900/20 to-black min-h-screen">
          <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-md border-b border-purple-500/30">
            <div className="px-4 py-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent mb-4">
                Mensajes
              </h1>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-purple-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar conversaciones..."
                  className="w-full bg-purple-900/20 border border-purple-500/30 rounded-full pl-10 pr-4 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          </div>

          <div className="divide-y divide-purple-500/10">
            {allUsers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <MessageCircle className="w-16 h-16 text-purple-400/40 mb-4" />
                <p className="text-purple-300/60 text-lg">No hay conversaciones</p>
                <p className="text-purple-300/40 text-sm mt-2">Los usuarios conectados aparecerán aquí</p>
              </div>
            ) : (
              allUsers
                .filter(chatUser => 
                  searchQuery === '' || 
                  chatUser.name.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map(chatUser => {
                  const lastMessage = getLastMessage(chatUser.id);
                  const messageCount = getChatMessages(chatUser.id).length;
                  const isOnline = connectedUsers.some(u => u.id === chatUser.id);
                  
                  return (
                    <div
                      key={chatUser.id}
                      onClick={() => setSelectedChatUser(chatUser)}
                      className="px-4 py-4 hover:bg-purple-900/20 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative flex-shrink-0">
                          {renderAvatarWithFrame(chatUser, 'w-14 h-14')}
                          {isOnline && (
                            <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-black"></div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-white truncate">{chatUser.name}</h3>
                            {lastMessage && (
                              <span className="text-xs text-purple-300/60">{getTimeAgo(lastMessage.timestamp)}</span>
                            )}
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-purple-300/60 truncate">
                              {lastMessage ? (
                                lastMessage.userId === user.id ? `Tú: ${lastMessage.content}` : lastMessage.content
                              ) : (
                                'Iniciar conversación'
                              )}
                            </p>
                            {messageCount > 0 && (
                              <span className="ml-2 bg-purple-600 text-white text-xs px-2 py-0.5 rounded-full">
                                {messageCount}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>
      </div>
    );
  };

  const UsersScreen = () => {
    const allUsers = [user, ...connectedUsers, ...userProfiles];
    const uniqueUsers = allUsers.filter((user, index, self) => 
      index === self.findIndex(u => u.id === user.id)
    );

    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="relative min-h-screen bg-gradient-to-br from-purple-900 via-black to-blue-800 p-4">
          <div className="text-center py-6">
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-blue-600">
              Usuarios
            </h1>
            <p className="text-purple-300/80 mt-2">Comunidad Social Planet - {uniqueUsers.length} miembros</p>
            <div className="mt-2 text-green-400 text-sm">
              🟢 Conectados: {connectedUsers.length + 1} | 🔴 Desconectados: {uniqueUsers.length - connectedUsers.length - 1}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {uniqueUsers.map(profile => {
              const isConnected = connectedUsers.some(u => u.id === profile.id) || profile.id === user.id;
              
              return (
                <div 
                  key={profile.id} 
                  onClick={() => {
                    setViewingProfile(profile);
                    setCurrentPage('profile');
                  }}
                  className={`bg-gradient-to-br from-purple-800/30 to-black/80 rounded-xl p-6 border ${isConnected ? 'border-green-500/50 shadow-lg shadow-green-500/20' : 'border-purple-600/30'} transition-all duration-300 hover:scale-105 cursor-pointer`}
                >
                  <div className="text-center">
                    <div className="relative mb-4 inline-block">
                      {renderAvatarWithFrame(profile, 'w-24 h-24')}
                      
                      <div className={`absolute bottom-1 right-1 w-6 h-6 ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-500'} rounded-full border-2 border-black flex items-center justify-center`}>
                        {isConnected ? '🟢' : '⚫'}
                      </div>
                      
                      {profile.suspended && (
                        <div className="absolute inset-0 bg-red-600/80 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">SUSPENDIDO</span>
                        </div>
                      )}
                      
                      {isAdmin() && profile.id !== user.id && (
                        <button 
                          className="absolute -top-2 -left-2 w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs hover:bg-purple-700"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedUser(profile);
                            setShowUserActions(true);
                          }}
                        >
                          ⋮
                        </button>
                      )}

                      {profile.id === user.id && (
                        <div className="absolute -top-2 -left-2 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs">
                          👤
                        </div>
                      )}
                    </div>
                    
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {profile.name} {profile.id === user.id && '(Tú)'}
                    </h3>
                    <div className={`inline-block bg-gradient-to-r ${getQIColor(profile.qi)} px-3 py-1 rounded-full text-white text-sm font-bold mb-3`}>
                      QI: {profile.qi}
                    </div>
                    <p className="text-purple-300/80 text-sm mb-4">{profile.bio || 'Sin biografía'}</p>
                    <div className="flex justify-center space-x-4 text-sm text-purple-300/60 mb-2">
                      <span>{profile.posts || 0} posts</span>
                      <span>{profile.followers || 0} seguidores</span>
                    </div>
                    
                    {profile.id === user.id && (
                      <div className="flex justify-center items-center space-x-2 text-yellow-400 text-sm mb-2">
                        <Coins className="w-4 h-4" />
                        <span>{profile.planetas} 🪐</span>
                      </div>
                    )}
                    
                    <div className="text-xs">
                      {profile.role === 'admin' && (
                        <div className="text-purple-400 font-semibold">👑 ADMINISTRADOR</div>
                      )}
                      {profile.role === 'moderator' && (
                        <div className="text-yellow-400 font-semibold">🛡️ MODERADOR</div>
                      )}
                      <div className={`mt-1 ${isConnected ? 'text-green-400' : 'text-gray-500'}`}>
                        {isConnected ? '🟢 En línea' : '⚫ Desconectado'}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 bg-gradient-to-r from-purple-900/30 to-black/80 rounded-xl p-6 border border-purple-600/30">
            <h3 className="text-purple-400 font-semibold mb-4 text-center">📊 Estadísticas del Servidor</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="bg-black/40 rounded-lg p-3">
                <div className="text-2xl font-bold text-green-400">{connectedUsers.length + 1}</div>
                <div className="text-green-300 text-sm">En línea</div>
              </div>
              <div className="bg-black/40 rounded-lg p-3">
                <div className="text-2xl font-bold text-white">{uniqueUsers.length}</div>
                <div className="text-purple-300 text-sm">Total usuarios</div>
              </div>
              <div className="bg-black/40 rounded-lg p-3">
                <div className="text-2xl font-bold text-yellow-400">
                  {uniqueUsers.filter(u => u.role === 'moderator').length}
                </div>
                <div className="text-yellow-300 text-sm">Moderadores</div>
              </div>
              <div className="bg-black/40 rounded-lg p-3">
                <div className="text-2xl font-bold text-purple-400">
                  {uniqueUsers.filter(u => u.role === 'admin').length}
                </div>
                <div className="text-purple-300 text-sm">Admins</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ProfileScreen = () => {
    const profileUser = viewingProfile || user;
    const isOwnProfile = !viewingProfile || viewingProfile.id === user.id;
    const [wallCommentInput, setWallCommentInput] = useState('');
    const [bannerImage, setBannerImage] = useState(null);
    const [avatarImage, setAvatarImage] = useState(null);

    const handleBannerUpload = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setBannerImage(reader.result);
        };
        reader.readAsDataURL(file);
      }
    };

    const handleAvatarUpload = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setUser(prev => ({ ...prev, avatar: reader.result }));
        };
        reader.readAsDataURL(file);
      }
    };

    const handleWallComment = () => {
      if (!wallCommentInput.trim()) return;

      const newComment = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        content: wallCommentInput,
        timestamp: new Date().toISOString()
      };

      setProfileComments(prev => ({
        ...prev,
        [profileUser.id]: [...(prev[profileUser.id] || []), newComment]
      }));

      setWallCommentInput('');
    };

    const wallComments = profileComments[profileUser.id] || [];

    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="bg-gradient-to-b from-purple-900/20 to-black min-h-screen">
          {/* Banner */}
          <div className="relative h-64 overflow-hidden">
            {bannerImage ? (
              <img src={bannerImage} alt="Banner" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600"></div>
            )}
            <div className="absolute inset-0 bg-black/40"></div>
            {isOwnProfile && (
              <label className="absolute top-4 right-4 bg-black/60 hover:bg-black/80 p-2 rounded-full backdrop-blur-sm cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleBannerUpload}
                  className="hidden"
                />
                <Camera className="w-5 h-5 text-white" />
              </label>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
          </div>

          <div className="max-w-5xl mx-auto px-4">
            {/* Avatar y Info Principal */}
            <div className="relative -mt-24 mb-6">
              <div className="flex flex-col md:flex-row items-center md:items-end gap-6">
                <div className="relative">
                  {renderAvatarWithFrame(profileUser, 'w-40 h-40')}
                  {isOwnProfile && (
                    <label className="absolute bottom-2 right-2 bg-purple-600 hover:bg-purple-700 p-2 rounded-full cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        className="hidden"
                      />
                      <Camera className="w-4 h-4 text-white" />
                    </label>
                  )}
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                    <h1 className="text-4xl font-bold text-white">{profileUser.name}</h1>
                    {profileUser.role === 'admin' && (
                      <span className="inline-flex items-center gap-1 bg-purple-600/30 border border-purple-500 px-3 py-1 rounded-full text-sm">
                        <Crown className="w-4 h-4 text-purple-400" />
                        <span className="text-purple-300">Admin</span>
                      </span>
                    )}
                    {profileUser.role === 'moderator' && (
                      <span className="inline-flex items-center gap-1 bg-yellow-600/30 border border-yellow-500 px-3 py-1 rounded-full text-sm">
                        <Crown className="w-4 h-4 text-yellow-400" />
                        <span className="text-yellow-300">Moderador</span>
                      </span>
                    )}
                  </div>
                  
                  <p className="text-purple-300/80 mb-4 max-w-2xl">{profileUser.bio}</p>

                  {/* Estadísticas */}
                  <div className="flex flex-wrap justify-center md:justify-start gap-6 mb-4">
                    <div className="text-center">
                      <div className="font-bold text-xl text-white">{profileUser.posts}</div>
                      <div className="text-purple-300/60 text-sm">Posts</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold text-xl text-white">{profileUser.followers}</div>
                      <div className="text-purple-300/60 text-sm">Seguidores</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold text-xl text-white">{userClubs.length}</div>
                      <div className="text-purple-300/60 text-sm">Clubes</div>
                    </div>
                    <div className={`bg-gradient-to-r ${getQIColor(profileUser.qi)} px-4 py-2 rounded-full flex items-center gap-2`}>
                      <span className="text-white font-bold">QI {profileUser.qi}</span>
                    </div>
                    {isOwnProfile && (
                      <div className="bg-yellow-900/30 border border-yellow-600/40 px-4 py-2 rounded-full flex items-center gap-2">
                        <Coins className="w-5 h-5 text-yellow-400" />
                        <span className="text-yellow-400 font-bold">{profileUser.planetas}</span>
                      </div>
                    )}
                  </div>

                  {/* Botones de Acción */}
                  <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                    {isOwnProfile ? (
                      <>
                        <button 
                          onClick={() => setShowShop(true)}
                          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-6 py-2 rounded-full text-white font-semibold flex items-center gap-2"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          Tienda
                        </button>
                        <button className="bg-purple-900/40 hover:bg-purple-900/60 border border-purple-500/50 px-6 py-2 rounded-full text-white font-semibold flex items-center gap-2">
                          <Edit className="w-4 h-4" />
                          Editar Perfil
                        </button>
                      </>
                    ) : (
                      <>
                        <button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-6 py-2 rounded-full text-white font-semibold flex items-center gap-2">
                          <UserPlus className="w-4 h-4" />
                          Seguir
                        </button>
                        <button 
                          onClick={() => {
                            setSelectedChatUser(profileUser);
                            setCurrentPage('chats');
                          }}
                          className="bg-purple-900/40 hover:bg-purple-900/60 border border-purple-500/50 px-6 py-2 rounded-full text-white font-semibold flex items-center gap-2"
                        >
                          <MessageCircle className="w-4 h-4" />
                          Mensaje
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Tabs de Navegación */}
            <div className="border-b border-purple-500/30 mb-6">
              <div className="flex gap-8 overflow-x-auto">
                <button
                  onClick={() => setCurrentProfileTab('posts')}
                  className={`pb-4 px-2 border-b-2 transition-colors flex items-center gap-2 ${
                    currentProfileTab === 'posts'
                      ? 'border-purple-500 text-purple-400'
                      : 'border-transparent text-purple-300/60 hover:text-purple-300'
                  }`}
                >
                  <Grid className="w-4 h-4" />
                  Posts
                </button>
                <button
                  onClick={() => setCurrentProfileTab('about')}
                  className={`pb-4 px-2 border-b-2 transition-colors flex items-center gap-2 ${
                    currentProfileTab === 'about'
                      ? 'border-purple-500 text-purple-400'
                      : 'border-transparent text-purple-300/60 hover:text-purple-300'
                  }`}
                >
                  <User className="w-4 h-4" />
                  Sobre mí
                </button>
                <button
                  onClick={() => setCurrentProfileTab('frames')}
                  className={`pb-4 px-2 border-b-2 transition-colors flex items-center gap-2 ${
                    currentProfileTab === 'frames'
                      ? 'border-purple-500 text-purple-400'
                      : 'border-transparent text-purple-300/60 hover:text-purple-300'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                  Marcos ({profileUser.ownedFrames.length})
                </button>
                <button
                  onClick={() => setCurrentProfileTab('activity')}
                  className={`pb-4 px-2 border-b-2 transition-colors flex items-center gap-2 ${
                    currentProfileTab === 'activity'
                      ? 'border-purple-500 text-purple-400'
                      : 'border-transparent text-purple-300/60 hover:text-purple-300'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  Actividad
                </button>
                <button
                  onClick={() => setCurrentProfileTab('wall')}
                  className={`pb-4 px-2 border-b-2 transition-colors flex items-center gap-2 ${
                    currentProfileTab === 'wall'
                      ? 'border-purple-500 text-purple-400'
                      : 'border-transparent text-purple-300/60 hover:text-purple-300'
                  }`}
                >
                  <MessageCircle className="w-4 h-4" />
                  Muro ({wallComments.length})
                </button>
              </div>
            </div>

            {/* Contenido de los Tabs */}
            <div className="pb-8">
              {currentProfileTab === 'posts' && (
                <div className="space-y-4">
                  {posts.filter(p => p.userId === profileUser.id).length === 0 ? (
                    <div className="text-center py-20">
                      <Grid className="w-16 h-16 text-purple-400/40 mx-auto mb-4" />
                      <p className="text-purple-300/60">No hay posts todavía</p>
                    </div>
                  ) : (
                    posts.filter(p => p.userId === profileUser.id).map(post => (
                      <div key={post.id} className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/20 p-6">
                        <p className="text-white mb-4">{post.content}</p>
                        <div className="flex items-center gap-4 text-purple-300/60">
                          <button className="flex items-center gap-2 hover:text-red-400">
                            <Heart className="w-5 h-5" />
                            {post.likes}
                          </button>
                          <button className="flex items-center gap-2 hover:text-blue-400">
                            <MessageCircle className="w-5 h-5" />
                            {post.comments}
                          </button>
                          <span className="text-sm">{getTimeAgo(post.timestamp)}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {currentProfileTab === 'about' && (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl p-6 border border-purple-500/30">
                    <h3 className="text-lg font-semibold text-purple-400 mb-4">Información</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-purple-300/60">Email:</span>
                        <span className="text-white">{isOwnProfile ? profileUser.email : '***@***.com'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-300/60">QI:</span>
                        <span className="text-white">{profileUser.qi}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-300/60">Estado:</span>
                        <span className="text-green-400">● En línea</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-300/60">Rol:</span>
                        <span className="text-white capitalize">{profileUser.role}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl p-6 border border-purple-500/30">
                    <h3 className="text-lg font-semibold text-purple-400 mb-4">Estadísticas</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-black/40 rounded-lg">
                        <div className="text-2xl font-bold text-purple-400">{profileUser.posts}</div>
                        <div className="text-xs text-purple-300/60">Posts</div>
                      </div>
                      <div className="text-center p-4 bg-black/40 rounded-lg">
                        <div className="text-2xl font-bold text-blue-400">{profileUser.followers}</div>
                        <div className="text-xs text-blue-300/60">Seguidores</div>
                      </div>
                      <div className="text-center p-4 bg-black/40 rounded-lg">
                        <div className="text-2xl font-bold text-green-400">{profileUser.ownedFrames.length}</div>
                        <div className="text-xs text-green-300/60">Marcos</div>
                      </div>
                      <div className="text-center p-4 bg-black/40 rounded-lg">
                        <div className="text-2xl font-bold text-yellow-400">{userClubs.length}</div>
                        <div className="text-xs text-yellow-300/60">Clubes</div>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-2 bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl p-6 border border-purple-500/30">
                    <h3 className="text-lg font-semibold text-purple-400 mb-4">Biografía</h3>
                    <p className="text-purple-300/80">{profileUser.bio}</p>
                  </div>
                </div>
              )}

              {currentProfileTab === 'frames' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {profileUser.ownedFrames.length === 0 ? (
                    <div className="col-span-full text-center py-20">
                      <Bookmark className="w-16 h-16 text-purple-400/40 mx-auto mb-4" />
                      <p className="text-purple-300/60">No hay marcos coleccionados</p>
                      {isOwnProfile && (
                        <button
                          onClick={() => setShowShop(true)}
                          className="mt-4 bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-full text-white font-semibold"
                        >
                          Ir a la tienda
                        </button>
                      )}
                    </div>
                  ) : (
                    profileUser.ownedFrames.map(frameId => {
                      const frame = shopFrames.find(f => f.id === frameId);
                      if (!frame) return null;
                      return (
                        <div key={frameId} className="bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl p-4 border border-purple-500/30 hover:border-purple-500/60 transition-all">
                          <div className="relative w-20 h-20 mx-auto mb-3">
                            <div className="w-full h-full rounded-full bg-gradient-to-br from-purple-600 to-blue-600"></div>
                            {frame.svg}
                          </div>
                          <p className="text-white text-sm font-semibold text-center">{frame.name}</p>
                          <p className={`text-xs text-center ${getRarityColor(frame.rarity)}`}>{frame.rarity}</p>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {currentProfileTab === 'activity' && (
                <div className="space-y-4">
                  <div className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/20 p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-sm text-purple-300/60">Hace 2 horas</span>
                    </div>
                    <p className="text-white">Se unió al club <span className="text-purple-400 font-semibold">Gamers Planet</span></p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/20 p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                      <span className="text-sm text-purple-300/60">Hace 5 horas</span>
                    </div>
                    <p className="text-white">Compró el marco <span className="text-blue-400 font-semibold">Cósmico</span></p>
                  </div>
                </div>
              )}

              {currentProfileTab === 'wall' && (
                <div className="space-y-4">
                  <div className="bg-gradient-to-br from-purple-900/30 to-black/80 rounded-xl border border-purple-500/30 p-4">
                    <div className="flex space-x-3">
                      <img src={user.avatar} className="w-10 h-10 rounded-full" alt="" />
                      <div className="flex-1">
                        <textarea
                          value={wallCommentInput}
                          onChange={(e) => setWallCommentInput(e.target.value)}
                          placeholder={`Escribe algo en el muro de ${profileUser.name}...`}
                          className="w-full bg-black/40 border border-purple-500/20 rounded-lg px-4 py-3 text-white placeholder-purple-300/40 focus:outline-none focus:border-purple-400 resize-none"
                          rows="2"
                        />
                        <div className="flex justify-end mt-2">
                          <button
                            onClick={handleWallComment}
                            disabled={!wallCommentInput.trim()}
                            className={`px-4 py-2 rounded-full font-semibold text-sm ${
                              wallCommentInput.trim()
                                ? 'bg-gradient-to-r from-purple-500 to-blue-600 text-white'
                                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                            }`}
                          >
                            Publicar
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {wallComments.length === 0 ? (
                    <div className="text-center py-12">
                      <MessageCircle className="w-16 h-16 text-purple-400/40 mx-auto mb-4" />
                      <p className="text-purple-300/60">No hay comentarios en el muro</p>
                    </div>
                  ) : (
                    wallComments.map(comment => (
                      <div key={comment.id} className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/20 p-4">
                        <div className="flex space-x-3">
                          <img src={comment.userAvatar} className="w-10 h-10 rounded-full" alt="" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-semibold text-white">{comment.userName}</span>
                              <span className="text-purple-300/60 text-xs">{getTimeAgo(comment.timestamp)}</span>
                            </div>
                            <p className="text-white">{comment.content}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {isOwnProfile && (
              <div className="mt-8 text-center">
                <button
                  onClick={() => {
                    if (window.confirm('¿Seguro que quieres cerrar sesión?')) {
                      setCurrentPage('login');
                    }
                  }}
                  className="bg-red-600/20 hover:bg-red-600/40 border border-red-500/50 px-6 py-2 rounded-lg text-red-400 font-semibold flex items-center gap-2 mx-auto"
                >
                  <LogOut className="w-4 h-4" />
                  Cerrar Sesión
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const ClubsScreen = () => {
    const [clubMessageInput, setClubMessageInput] = useState('');
    const [showCreateClub, setShowCreateClub] = useState(false);

    const joinClub = (clubId) => {
      if (userClubs.includes(clubId)) {
        alert('Ya eres miembro de este club');
        return;
      }
      setUserClubs(prev => [...prev, clubId]);
      alert('¡Te has unido al club!');
    };

    const leaveClub = (clubId) => {
      setUserClubs(prev => prev.filter(id => id !== clubId));
      alert('Has salido del club');
      if (selectedClub?.id === clubId) {
        setSelectedClub(null);
      }
    };

    const sendClubMessage = () => {
      if (!clubMessageInput.trim() || !selectedClub) return;

      const message = {
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        content: clubMessageInput,
        timestamp: new Date().toISOString()
      };

      setClubMessages(prev => ({
        ...prev,
        [selectedClub.id]: [...(prev[selectedClub.id] || []), message]
      }));

      setClubMessageInput('');
    };

    const toggleVoiceChat = () => {
      setVoiceConnected(!voiceConnected);
    };

    if (selectedClub) {
      const messages = clubMessages[selectedClub.id] || [];
      const isMember = userClubs.includes(selectedClub.id);

      return (
        <div className="min-h-screen bg-black text-white flex flex-col">
          {/* Header del Club - Minimizado */}
          <div className="sticky top-0 z-30 bg-gradient-to-r from-purple-900/90 to-black/90 backdrop-blur-md border-b border-purple-500/30">
            <div className="px-4 py-3 flex items-center gap-3">
              <button onClick={() => setSelectedClub(null)} className="text-purple-400 hover:text-purple-300">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <img src={selectedClub.avatar} alt="" className="w-10 h-10 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="font-bold text-white truncate">{selectedClub.name}</h2>
                  {selectedClub.isPrivate ? (
                    <Lock className="w-3 h-3 text-yellow-400 flex-shrink-0" />
                  ) : (
                    <Globe className="w-3 h-3 text-green-400 flex-shrink-0" />
                  )}
                </div>
                <p className="text-xs text-purple-300/60 flex items-center gap-2">
                  <Users className="w-3 h-3" />
                  {selectedClub.members} miembros
                </p>
              </div>
              <div>
                {isMember ? (
                  <button
                    onClick={() => leaveClub(selectedClub.id)}
                    className="bg-red-600/20 border border-red-500/50 px-3 py-1 rounded-lg text-red-400 text-xs font-semibold hover:bg-red-600/30"
                  >
                    Salir
                  </button>
                ) : (
                  <button
                    onClick={() => joinClub(selectedClub.id)}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 px-3 py-1 rounded-lg text-white text-xs font-semibold"
                  >
                    Unirse
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Contenido del Club */}
          {isMember ? (
            <>
              {/* Chat de Texto */}
              {clubActiveFeature === 'chat' && (
                <>
                  <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 bg-gradient-to-b from-purple-900/10 to-black">
                    {messages.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <MessageCircle className="w-16 h-16 text-purple-400/40 mb-4" />
                        <p className="text-purple-300/60 text-lg">Chat del club</p>
                        <p className="text-purple-300/40 text-sm mt-2">Sé el primero en enviar un mensaje</p>
                      </div>
                    ) : (
                      messages.map((msg, index) => {
                        const showAvatar = index === 0 || messages[index - 1].userId !== msg.userId;
                        
                        return (
                          <div key={msg.id} className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-10">
                              {showAvatar && (
                                <img src={msg.userAvatar} className="w-10 h-10 rounded-full" alt="" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              {showAvatar && (
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-semibold text-sm text-purple-300">{msg.userName}</span>
                                  <span className="text-xs text-purple-300/40">{getTimeAgo(msg.timestamp)}</span>
                                </div>
                              )}
                              <div className="bg-purple-900/30 px-4 py-2 rounded-2xl rounded-tl-sm inline-block">
                                <p className="text-white text-sm">{msg.content}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  <div className="sticky bottom-0 bg-black/90 backdrop-blur-md border-t border-purple-500/30 p-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowClubFeatures(!showClubFeatures)}
                        className="p-3 bg-purple-900/40 hover:bg-purple-900/60 rounded-full transition-colors"
                      >
                        <Plus className={`w-5 h-5 text-purple-400 transition-transform ${showClubFeatures ? 'rotate-45' : ''}`} />
                      </button>
                      <input
                        type="text"
                        value={clubMessageInput}
                        onChange={(e) => setClubMessageInput(e.target.value)}
                        placeholder="Mensaje en el club..."
                        className="flex-1 bg-purple-900/20 border border-purple-500/30 rounded-full px-5 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400"
                        onKeyPress={(e) => e.key === 'Enter' && sendClubMessage()}
                      />
                      <button
                        onClick={sendClubMessage}
                        disabled={!clubMessageInput.trim()}
                        className={`p-3 rounded-full ${
                          clubMessageInput.trim()
                            ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                            : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                        }`}
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Menú de Funciones */}
                    {showClubFeatures && (
                      <div className="mt-3 grid grid-cols-3 gap-2">
                        <button
                          onClick={() => {
                            setClubActiveFeature('voice');
                            setShowClubFeatures(false);
                          }}
                          className="flex flex-col items-center gap-2 p-3 bg-green-600/20 hover:bg-green-600/30 rounded-lg border border-green-500/30 transition-colors"
                        >
                          <Mic className="w-6 h-6 text-green-400" />
                          <span className="text-xs text-green-300 font-semibold">Voz</span>
                        </button>
                        <button
                          onClick={() => {
                            setClubActiveFeature('cinema');
                            setShowClubFeatures(false);
                          }}
                          className="flex flex-col items-center gap-2 p-3 bg-red-600/20 hover:bg-red-600/30 rounded-lg border border-red-500/30 transition-colors"
                        >
                          <Film className="w-6 h-6 text-red-400" />
                          <span className="text-xs text-red-300 font-semibold">Cine</span>
                        </button>
                        <button
                          onClick={() => {
                            setClubActiveFeature('roleplay');
                            setShowClubFeatures(false);
                          }}
                          className="flex flex-col items-center gap-2 p-3 bg-pink-600/20 hover:bg-pink-600/30 rounded-lg border border-pink-500/30 transition-colors"
                        >
                          <Gamepad2 className="w-6 h-6 text-pink-400" />
                          <span className="text-xs text-pink-300 font-semibold">Roleplay</span>
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* Chat de Voz */}
              {clubActiveFeature === 'voice' && (
                <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-green-900/10 to-black">
                  <div className="text-center max-w-md px-4">
                    <div className={`w-32 h-32 mx-auto mb-6 rounded-full flex items-center justify-center ${
                      voiceConnected ? 'bg-green-600 animate-pulse' : 'bg-purple-900/40'
                    }`}>
                      <Mic className={`w-16 h-16 ${voiceConnected ? 'text-white' : 'text-purple-400'}`} />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-3">
                      {voiceConnected ? 'Conectado a Chat de Voz' : 'Chat de Voz'}
                    </h3>
                    <p className="text-purple-300/60 mb-6">
                      {voiceConnected 
                        ? 'Estás en el canal de voz. Otros miembros pueden escucharte.'
                        : 'Únete al canal de voz para hablar con otros miembros del club'
                      }
                    </p>
                    
                    {voiceConnected && (
                      <div className="bg-purple-900/30 rounded-xl p-4 mb-6">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-sm text-purple-300">En el canal:</span>
                          <span className="text-sm text-purple-400 font-semibold">{Math.floor(Math.random() * 5) + 1} usuarios</span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center gap-3 bg-black/40 p-2 rounded-lg">
                            <img src={user.avatar} className="w-8 h-8 rounded-full" alt="" />
                            <span className="text-white text-sm flex-1">{user.name} (Tú)</span>
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                          </div>
                        </div>
                      </div>
                    )}

                    <button
                      onClick={toggleVoiceChat}
                      className={`px-8 py-3 rounded-full font-semibold ${
                        voiceConnected
                          ? 'bg-red-600 hover:bg-red-700 text-white'
                          : 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white'
                      }`}
                    >
                      {voiceConnected ? 'Desconectar' : 'Conectar a Voz'}
                    </button>
                  </div>
                </div>
              )}

              {/* Sala de Cine */}
              {clubActiveFeature === 'cinema' && (
                <div className="flex-1 flex flex-col bg-gradient-to-b from-red-900/10 to-black">
                  <div className="flex-1 flex items-center justify-center p-4">
                    <div className="w-full max-w-4xl">
                      {cinemaMovie ? (
                        <div className="bg-black rounded-xl overflow-hidden">
                          <div className="aspect-video bg-gradient-to-br from-red-900/20 to-purple-900/20 flex items-center justify-center relative">
                            <Film className="w-24 h-24 text-purple-400/40" />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-center">
                                <p className="text-white text-xl mb-2">🎬 {cinemaMovie.title}</p>
                                <p className="text-purple-300/60 text-sm">Reproduciendo...</p>
                              </div>
                            </div>
                          </div>
                          <div className="p-4 bg-black/60">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-white font-semibold">{cinemaMovie.title}</span>
                              <button
                                onClick={() => setCinemaMovie(null)}
                                className="text-red-400 hover:text-red-300"
                              >
                                <X className="w-5 h-5" />
                              </button>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-purple-300/60">
                              <Users className="w-3 h-3" />
                              <span>{Math.floor(Math.random() * 10) + 2} viendo</span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center">
                          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-purple-900/40 flex items-center justify-center">
                            <Film className="w-16 h-16 text-purple-400" />
                          </div>
                          <h3 className="text-2xl font-bold text-white mb-3">Sala de Cine</h3>
                          <p className="text-purple-300/60 mb-6">Ver videos y películas juntos en tiempo real</p>
                          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                            <button
                              onClick={() => setCinemaMovie({ title: 'Video del Club', url: '' })}
                              className="bg-gradient-to-r from-red-600 to-pink-600 px-6 py-3 rounded-lg text-white font-semibold hover:from-red-700 hover:to-pink-700"
                            >
                              Iniciar Video
                            </button>
                            <button className="bg-purple-900/40 border border-purple-500/50 px-6 py-3 rounded-lg text-white font-semibold hover:bg-purple-900/60">
                              Buscar Video
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Roleplay */}
              {clubActiveFeature === 'roleplay' && (
                <div className="flex-1 overflow-y-auto bg-gradient-to-b from-pink-900/10 to-black p-4">
                  <div className="max-w-4xl mx-auto">
                    {roleplayScenario ? (
                      <div className="space-y-4">
                        <div className="bg-gradient-to-br from-pink-900/30 to-purple-900/30 rounded-xl p-6 border border-pink-500/30">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h3 className="text-xl font-bold text-white mb-2">{roleplayScenario.title}</h3>
                              <p className="text-purple-300/80 text-sm">{roleplayScenario.description}</p>
                            </div>
                            <button
                              onClick={() => setRoleplayScenario(null)}
                              className="text-pink-400 hover:text-pink-300"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="px-3 py-1 bg-pink-600/30 rounded-full text-pink-300">
                              {roleplayScenario.genre}
                            </span>
                            <span className="text-purple-300/60 flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {Math.floor(Math.random() * 5) + 1} participantes
                            </span>
                          </div>
                        </div>

                        <div className="bg-purple-900/20 rounded-xl p-6 border border-purple-500/20">
                          <h4 className="text-white font-semibold mb-4">Tu Personaje</h4>
                          <div className="bg-black/40 rounded-lg p-4 mb-4">
                            <div className="flex items-center gap-3 mb-3">
                              <img src={user.avatar} className="w-12 h-12 rounded-full" alt="" />
                              <div>
                                <input
                                  type="text"
                                  placeholder="Nombre del personaje..."
                                  className="bg-purple-900/30 border border-purple-500/30 rounded px-3 py-1 text-white text-sm mb-1 w-full"
                                />
                                <input
                                  type="text"
                                  placeholder="Rol (ej: Guerrero, Mago)..."
                                  className="bg-purple-900/30 border border-purple-500/30 rounded px-3 py-1 text-white text-xs w-full"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div className="flex items-start gap-3 bg-black/20 p-3 rounded-lg">
                              <img src={user.avatar} className="w-8 h-8 rounded-full" alt="" />
                              <div className="flex-1">
                                <div className="text-pink-400 text-sm font-semibold mb-1">Narrador</div>
                                <p className="text-white text-sm italic">Te encuentras en una misteriosa ciudad espacial...</p>
                              </div>
                            </div>
                          </div>

                          <div className="mt-4">
                            <textarea
                              placeholder="Escribe tu acción... (Usa * para acciones: *mira alrededor*)"
                              className="w-full bg-purple-900/20 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 resize-none"
                              rows="3"
                            />
                            <div className="flex justify-end mt-2">
                              <button className="bg-gradient-to-r from-pink-600 to-purple-600 px-6 py-2 rounded-lg text-white font-semibold">
                                Enviar Acción
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-purple-900/40 flex items-center justify-center">
                          <Gamepad2 className="w-16 h-16 text-pink-400" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-3">Roleplay</h3>
                        <p className="text-purple-300/60 mb-6 max-w-md mx-auto">
                          Crea historias colaborativas con otros miembros del club
                        </p>

                        <div className="grid md:grid-cols-3 gap-4 max-w-3xl mx-auto">
                          <div
                            onClick={() => setRoleplayScenario({ 
                              title: 'Aventura Espacial', 
                              description: 'Explora galaxias desconocidas',
                              genre: 'Ciencia Ficción'
                            })}
                            className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 rounded-xl p-6 border border-blue-500/30 cursor-pointer hover:border-blue-500/60 transition-all"
                          >
                            <div className="text-4xl mb-3">🚀</div>
                            <h4 className="text-white font-semibold mb-2">Aventura Espacial</h4>
                            <p className="text-purple-300/60 text-sm">Sci-Fi</p>
                          </div>

                          <div
                            onClick={() => setRoleplayScenario({ 
                              title: 'Reino Fantástico', 
                              description: 'Magia y criaturas míticas',
                              genre: 'Fantasía'
                            })}
                            className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 rounded-xl p-6 border border-purple-500/30 cursor-pointer hover:border-purple-500/60 transition-all"
                          >
                            <div className="text-4xl mb-3">⚔️</div>
                            <h4 className="text-white font-semibold mb-2">Reino Fantástico</h4>
                            <p className="text-purple-300/60 text-sm">Fantasía</p>
                          </div>

                          <div
                            onClick={() => setRoleplayScenario({ 
                              title: 'Ciudad Cyberpunk', 
                              description: 'Futuro distópico y tecnología',
                              genre: 'Cyberpunk'
                            })}
                            className="bg-gradient-to-br from-pink-900/30 to-red-900/30 rounded-xl p-6 border border-pink-500/30 cursor-pointer hover:border-pink-500/60 transition-all"
                          >
                            <div className="text-4xl mb-3">🌃</div>
                            <h4 className="text-white font-semibold mb-2">Ciudad Cyberpunk</h4>
                            <p className="text-purple-300/60 text-sm">Cyberpunk</p>
                          </div>
                        </div>

                        <button className="mt-6 bg-gradient-to-r from-pink-600 to-purple-600 px-8 py-3 rounded-full text-white font-semibold hover:from-pink-700 hover:to-purple-700">
                          Crear Escenario Personalizado
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <Lock className="w-16 h-16 text-purple-400/40 mx-auto mb-4" />
                <p className="text-purple-300/60 text-lg mb-4">Únete al club para ver el chat</p>
                <button
                  onClick={() => joinClub(selectedClub.id)}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 px-6 py-3 rounded-full text-white font-semibold"
                >
                  Unirse al Club
                </button>
              </div>
            </div>
          )}
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-black text-white pb-20">
        <div className="bg-gradient-to-b from-purple-900/20 to-black min-h-screen">
          <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-md border-b border-purple-500/30">
            <div className="px-4 py-4">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
                  Clubes
                </h1>
                <button
                  data-create-club
                  onClick={() => setShowCreateClub(true)}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 px-4 py-2 rounded-full text-white text-sm font-semibold flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Crear Club
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-purple-400" />
                <input
                  type="text"
                  placeholder="Buscar clubes..."
                  className="w-full bg-purple-900/20 border border-purple-500/30 rounded-full pl-10 pr-4 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="px-4 pt-4">
            <div className="flex gap-4 border-b border-purple-500/30 mb-6">
              <button className="pb-3 px-2 border-b-2 border-purple-500 text-purple-400 font-semibold">
                Explorar
              </button>
              <button className="pb-3 px-2 border-b-2 border-transparent text-purple-300/60 hover:text-purple-300">
                Mis Clubes ({userClubs.length})
              </button>
            </div>
          </div>

          {/* Lista de Clubes */}
          <div className="px-4 space-y-4">
            {clubs.map(club => {
              const isMember = userClubs.includes(club.id);
              
              return (
                <div
                  key={club.id}
                  className="bg-gradient-to-br from-purple-900/20 to-black/80 rounded-xl border border-purple-500/30 overflow-hidden hover:border-purple-500/60 transition-all"
                >
                  <div className="relative h-24">
                    <img src={club.banner} alt="" className="w-full h-full object-cover opacity-40" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                    <div className="absolute top-2 right-2">
                      {club.isPrivate ? (
                        <span className="bg-yellow-600/80 px-2 py-1 rounded-full text-xs text-white flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Privado
                        </span>
                      ) : (
                        <span className="bg-green-600/80 px-2 py-1 rounded-full text-xs text-white flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          Público
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="p-4">
                    <div className="flex gap-4">
                      <img src={club.avatar} alt="" className="w-16 h-16 rounded-xl object-cover -mt-12 border-4 border-black" />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-bold text-lg text-white mb-1">{club.name}</h3>
                            <p className="text-sm text-purple-300/80 mb-2">{club.description}</p>
                            <div className="flex items-center gap-3 text-xs text-purple-300/60">
                              <span className="flex items-center gap-1">
                                <Users className="w-3 h-3" />
                                {club.members} miembros
                              </span>
                              <span className="px-2 py-0.5 bg-purple-600/30 rounded-full">{club.category}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-3 mt-4">
                      <button
                        onClick={() => setSelectedClub(club)}
                        className="flex-1 bg-purple-900/40 border border-purple-500/50 px-4 py-2 rounded-lg text-white font-semibold hover:bg-purple-900/60"
                      >
                        Ver Club
                      </button>
                      {isMember ? (
                        <button
                          onClick={() => leaveClub(club.id)}
                          className="px-4 py-2 rounded-lg border border-red-500/50 text-red-400 font-semibold hover:bg-red-600/20"
                        >
                          Salir
                        </button>
                      ) : (
                        <button
                          onClick={() => joinClub(club.id)}
                          className="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold"
                        >
                          Unirse
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Crear Club */}
        {showCreateClub && (
          <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
            <div className="bg-gradient-to-br from-purple-900/90 to-black border border-purple-600/50 rounded-xl p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-white">Crear Nuevo Club</h2>
                <button onClick={() => setShowCreateClub(false)} className="text-purple-400 hover:text-purple-300">✕</button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-purple-300/80 mb-2 block">Nombre del Club</label>
                  <input
                    type="text"
                    placeholder="Ej: Aventureros Espaciales"
                    className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400"
                  />
                </div>
                
                <div>
                  <label className="text-sm text-purple-300/80 mb-2 block">Descripción</label>
                  <textarea
                    placeholder="Describe tu club..."
                    rows="3"
                    className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-purple-300/60 focus:outline-none focus:border-purple-400 resize-none"
                  />
                </div>

                <div>
                  <label className="text-sm text-purple-300/80 mb-2 block">Categoría</label>
                  <select className="w-full bg-black/60 border border-purple-500/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-400">
                    <option>Gaming</option>
                    <option>Arte</option>
                    <option>Tech</option>
                    <option>Música</option>
                    <option>Deportes</option>
                    <option>Otro</option>
                  </select>
                </div>

                <div className="flex items-center gap-3">
                  <input type="checkbox" id="private" className="w-4 h-4" />
                  <label htmlFor="private" className="text-sm text-purple-300/80">
                    Club privado (requiere aprobación para unirse)
                  </label>
                </div>

                <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 py-3 rounded-lg text-white font-semibold">
                  Crear Club
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const ShopModal = () => {
    if (!showShop) return null;

    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
        <div className="bg-gradient-to-br from-purple-900/90 to-black border border-purple-600/50 rounded-xl p-6 w-full max-w-4xl max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-3">
              <ShoppingCart className="w-8 h-8 text-purple-400" />
              <h2 className="text-2xl font-bold text-white">🪐 Tienda de Marcos</h2>
            </div>
            <button onClick={() => setShowShop(false)} className="text-purple-400 text-xl hover:text-purple-300">✕</button>
          </div>

          <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 rounded-lg p-4 mb-6 border border-yellow-600/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Coins className="w-6 h-6 text-yellow-400" />
                <span className="text-xl font-bold text-yellow-400">
                  {user.planetas} Planetas 🪐
                </span>
              </div>
              <button
                onClick={claimDailyPlanetas}
                className="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-lg text-white font-semibold transition-all hover:scale-105"
              >
                🎁 Planetas Diarios
              </button>
            </div>
          </div>

          {user.frameId && (
            <div className="bg-black/40 rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold text-green-400 mb-3">✨ Marco Equipado</h3>
              <div className="flex items-center space-x-4">
                {renderAvatarWithFrame(user, 'w-16 h-16')}
                <div>
                  <p className="text-white font-semibold">
                    {shopFrames.find(f => f.id === user.frameId)?.name}
                  </p>
                  <p className="text-gray-400 text-sm">
                    {shopFrames.find(f => f.id === user.frameId)?.description}
                  </p>
                </div>
                <button
                  onClick={unequipFrame}
                  className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-sm"
                >
                  Desequipar
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {shopFrames.map(frame => {
              const isOwned = user.ownedFrames.includes(frame.id);
              const isEquipped = user.frameId === frame.id;
              const canAfford = user.planetas >= frame.price;

              return (
                <div key={frame.id} className={`bg-gradient-to-br from-purple-800/30 to-black/80 rounded-xl p-4 border transition-all duration-300 hover:scale-105 ${
                  isOwned ? 'border-green-500/50 shadow-lg shadow-green-500/20' : 'border-purple-600/30'
                }`}>
                  <div className="text-center">
                    <div className="relative mb-3">
                      <div className="relative w-20 h-20 mx-auto">
                        <div className="w-full h-full rounded-full bg-gradient-to-br from-purple-600 to-blue-600"></div>
                        {frame.svg}
                      </div>
                      {isOwned && (
                        <div className="absolute -top-2 -right-2 bg-green-500 rounded-full w-6 h-6 flex items-center justify-center">
                          ✓
                        </div>
                      )}
                      {isEquipped && (
                        <div className="absolute -bottom-2 -right-2 bg-blue-500 rounded-full w-6 h-6 flex items-center justify-center">
                          👑
                        </div>
                      )}
                    </div>

                    <h3 className="text-lg font-semibold text-white mb-1">{frame.name}</h3>
                    <p className={`text-sm font-medium mb-2 ${getRarityColor(frame.rarity)}`}>
                      {frame.rarity.toUpperCase()}
                    </p>
                    <p className="text-gray-400 text-xs mb-3">{frame.description}</p>

                    <div className="flex items-center justify-center space-x-2 mb-3">
                      <Coins className="w-4 h-4 text-yellow-400" />
                      <span className="text-yellow-400 font-bold">{frame.price}</span>
                      <span className="text-yellow-400">🪐</span>
                    </div>

                    {isEquipped ? (
                      <button className="w-full bg-blue-600 py-2 rounded-lg text-white font-semibold cursor-default">
                        ✨ Equipado
                      </button>
                    ) : isOwned ? (
                      <button
                        onClick={() => equipFrame(frame.id)}
                        className="w-full bg-green-600 hover:bg-green-700 py-2 rounded-lg text-white font-semibold"
                      >
                        👑 Equipar
                      </button>
                    ) : (
                      <button
                        onClick={() => buyFrame(frame.id)}
                        disabled={!canAfford}
                        className={`w-full py-2 rounded-lg font-semibold ${
                          canAfford
                            ? 'bg-purple-600 hover:bg-purple-700 text-white'
                            : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                        }`}
                      >
                        {canAfford ? '🛒 Comprar' : '🔒 Sin planetas'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 text-center text-purple-300/60 text-sm">
            💡 Los marcos se sobreponen alrededor de tu avatar como en Amino
          </div>
        </div>
      </div>
    );
  };

  const AdminPanel = () => {
    if (!showAdminPanel) return null;
    
    const allUsers = [user, ...connectedUsers, ...userProfiles].filter((user, index, self) => 
      index === self.findIndex(u => u.id === user.id)
    );
    
    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
        <div className="bg-gradient-to-br from-purple-900/90 to-black border border-purple-600/50 rounded-xl p-6 w-full max-w-4xl max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">🛡️ Panel de Administración</h2>
            <button onClick={() => setShowAdminPanel(false)} className="text-purple-400 text-xl hover:text-purple-300">✕</button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-black/40 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-green-400">{connectedUsers.length + 1}</div>
              <div className="text-green-300 text-sm">🟢 En línea</div>
            </div>
            <div className="bg-black/40 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-white">{allUsers.length}</div>
              <div className="text-purple-300 text-sm">👥 Total</div>
            </div>
            <div className="bg-black/40 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-yellow-400">
                {allUsers.filter(u => u.role === 'moderator').length}
              </div>
              <div className="text-yellow-300 text-sm">🛡️ Mods</div>
            </div>
            <div className="bg-black/40 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-red-400">
                {allUsers.filter(u => u.suspended).length}
              </div>
              <div className="text-red-300 text-sm">🚫 Suspendidos</div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-purple-400 mb-4">👥 Gestión de Usuarios</h3>
            <div className="max-h-96 overflow-y-auto space-y-3">
              {allUsers.filter(u => u.id !== user.id).map(profile => {
                const isConnected = connectedUsers.some(u => u.id === profile.id);
                return (
                  <div key={profile.id} className={`flex items-center justify-between rounded-lg p-4 ${isConnected ? 'bg-green-900/20 border border-green-600/30' : 'bg-black/40 border border-purple-600/20'}`}>
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        {renderAvatarWithFrame(profile, 'w-12 h-12')}
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${isConnected ? 'bg-green-500' : 'bg-gray-500'} rounded-full border-2 border-black`}></div>
                      </div>
                      <div>
                        <p className="text-white font-semibold flex items-center">
                          {profile.name}
                          {profile.role === 'admin' && <Crown className="w-4 h-4 text-purple-400 ml-1" />}
                          {profile.role === 'moderator' && <Crown className="w-4 h-4 text-yellow-400 ml-1" />}
                        </p>
                        <p className="text-purple-300/60 text-sm">
                          {profile.email} • QI: {profile.qi} • {isConnected ? '🟢 En línea' : '⚫ Desconectado'}
                          {profile.suspended && <span className="text-red-500"> (Suspendido)</span>}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {!profile.suspended && (
                        <button 
                          onClick={() => suspendUser(profile.id)}
                          className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-sm"
                        >
                          🚫 Suspender
                        </button>
                      )}
                      {profile.role !== 'moderator' && profile.role !== 'admin' && (
                        <button 
                          onClick={() => makeUserModerator(profile.id)}
                          className="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-white text-sm"
                        >
                          👑 Hacer Mod
                        </button>
                      )}
                      {isConnected && (
                        <button 
                          onClick={() => {
                            gameServer.disconnect(profile.id);
                            alert(`Usuario ${profile.name} desconectado del servidor`);
                          }}
                          className="bg-orange-600 hover:bg-orange-700 px-3 py-1 rounded text-white text-sm"
                        >
                          🔌 Desconectar
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 bg-purple-800/20 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-purple-400 mb-4">🖥️ Controles del Servidor</h3>
            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => alert('Enviando mensaje global...')}
                className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white font-semibold"
              >
                📢 Mensaje Global
              </button>
              <button 
                onClick={() => alert('Reiniciando servidor...')}
                className="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded text-white font-semibold"
              >
                🔄 Reiniciar Servidor
              </button>
              <button 
                onClick={() => {
                  const connected = gameServer.getConnectedUsers();
                  alert(`Servidor: SocialPlanet-01\nUptime: ${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m\nUsuarios conectados: ${connected.length}\nMemoria: ${Math.floor(Math.random() * 80 + 20)}%`);
                }}
                className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white font-semibold"
              >
                📊 Estado Servidor
              </button>
              <button className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded text-white font-semibold">
                ⚙️ Configuración
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const UserActionsModal = () => {
    if (!showUserActions || !selectedUser) return null;
    
    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-gradient-to-br from-purple-900/90 to-black border border-purple-600/50 rounded-xl p-6 w-96">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-white">Acciones de Usuario</h2>
            <button onClick={() => setShowUserActions(false)} className="text-purple-400 hover:text-purple-300">✕</button>
          </div>

          <div className="text-center mb-6">
            {renderAvatarWithFrame(selectedUser, 'w-16 h-16')}
            <h3 className="text-white font-semibold mt-2">{selectedUser.name}</h3>
            <p className="text-purple-300/60 text-sm">{selectedUser.email}</p>
          </div>

          <div className="space-y-3">
            {selectedUser.role !== 'moderator' && selectedUser.role !== 'admin' && (
              <button 
                onClick={() => makeUserModerator(selectedUser.id)}
                className="w-full bg-blue-600 hover:bg-blue-700 py-3 rounded text-white font-semibold"
              >
                👑 Hacer Moderador
              </button>
            )}
            
            {!selectedUser.suspended && (
              <button 
                onClick={() => suspendUser(selectedUser.id)}
                className="w-full bg-red-600 hover:bg-red-700 py-3 rounded text-white font-semibold"
              >
                🚫 Suspender Usuario
              </button>
            )}

            <button 
              onClick={() => {
                if (window.confirm(`¿Resetear la cuenta de ${selectedUser.name}?`)) {
                  setUserProfiles(prev => prev.map(profile => 
                    profile.id === selectedUser.id ? { 
                      ...profile, 
                      posts: 0, 
                      followers: 0, 
                      following: 0, 
                      qi: 100,
                      planetas: 50
                    } : profile
                  ));
                  setShowUserActions(false);
                  alert('Cuenta reseteada exitosamente');
                }
              }}
              className="w-full bg-orange-600 hover:bg-orange-700 py-3 rounded text-white font-semibold"
            >
              🔄 Resetear Cuenta
            </button>
          </div>
        </div>
      </div>
    );
  };

  const NavigationBar = () => {
    if (currentPage === 'login' || selectedClub) return null;
    
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-black to-black/90 border-t border-purple-600/30 z-40">
        <div className="flex justify-around items-center py-3">
          <button
            onClick={() => setCurrentPage('home')}
            className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-colors ${
              currentPage === 'home' 
                ? 'text-purple-400 bg-purple-900/30' 
                : 'text-purple-300/60 hover:text-purple-400'
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs font-semibold">Inicio</span>
          </button>

          <button
            onClick={() => setCurrentPage('clubs')}
            className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-colors ${
              currentPage === 'clubs' 
                ? 'text-purple-400 bg-purple-900/30' 
                : 'text-purple-300/60 hover:text-purple-400'
            }`}
          >
            <Users className="w-6 h-6" />
            <span className="text-xs font-semibold">Clubes</span>
          </button>

          <button
            onClick={() => setCurrentPage('chats')}
            className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-colors relative ${
              currentPage === 'chats' 
                ? 'text-purple-400 bg-purple-900/30' 
                : 'text-purple-300/60 hover:text-purple-400'
            }`}
          >
            <MessageCircle className="w-6 h-6" />
            <span className="text-xs font-semibold">Chats</span>
            {Object.keys(privateChats).length > 0 && (
              <span className="absolute top-1 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
            )}
          </button>

          <button
            onClick={() => {
              setViewingProfile(null);
              setCurrentPage('profile');
            }}
            className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-colors ${
              currentPage === 'profile' 
                ? 'text-purple-400 bg-purple-900/30' 
                : 'text-purple-300/60 hover:text-purple-400'
            }`}
          >
            <div className="relative">
              <img src={user.avatar} className="w-6 h-6 rounded-full border border-purple-400" alt="" />
            </div>
            <span className="text-xs font-semibold">Perfil</span>
          </button>
        </div>
      </div>
    );
  };

  const CreateButton = () => {
    if (currentPage === 'login') return null;
    
    return (
      <>
        {/* Menú de Creación */}
        {showCreateMenu && (
          <div className="fixed inset-0 bg-black/60 z-40" onClick={() => setShowCreateMenu(false)}>
            <div 
              className="fixed bottom-24 right-4 bg-gradient-to-br from-purple-900/95 to-black/95 backdrop-blur-md rounded-2xl border border-purple-500/50 p-2 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="space-y-2 min-w-[200px]">
                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    const content = prompt('Escribe tu publicación:');
                    if (content?.trim()) {
                      const newPost = {
                        id: Date.now(),
                        userId: user.id,
                        userName: user.name,
                        userAvatar: user.avatar,
                        userRole: user.role,
                        userFrameId: user.frameId,
                        content: content,
                        timestamp: new Date().toISOString(),
                        likes: 0,
                        comments: 0
                      };
                      setPosts(prev => [newPost, ...prev]);
                      setUser(prev => ({ ...prev, posts: prev.posts + 1 }));
                      setCurrentPage('home');
                    }
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-purple-600/20 rounded-xl transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <Edit className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-semibold">Publicación</div>
                    <div className="text-purple-300/60 text-xs">Comparte con todos</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    setCurrentPage('clubs');
                    setTimeout(() => {
                      const btn = document.querySelector('[data-create-club]');
                      if (btn) btn.click();
                    }, 100);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-purple-600/20 rounded-xl transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-semibold">Club</div>
                    <div className="text-purple-300/60 text-xs">Crea una comunidad</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    setShowShop(true);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-purple-600/20 rounded-xl transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-semibold">Marco</div>
                    <div className="text-purple-300/60 text-xs">Personaliza tu perfil</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Botón Flotante */}
        <div className="fixed bottom-24 right-4 z-50">
          <button
            onClick={() => setShowCreateMenu(!showCreateMenu)}
            className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all ${
              showCreateMenu
                ? 'bg-red-600 hover:bg-red-700 rotate-45'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 hover:scale-110'
            }`}
          >
            <Plus className="w-7 h-7 text-white" />
          </button>
        </div>
      </>
    );
  };

  const AdminButton = () => {
    if (!isAdmin() || currentPage === 'login') return null;
    
    return (
      <div className="fixed top-4 right-4 z-40">
        <button
          onClick={() => setShowAdminPanel(true)}
          className="bg-gradient-to-br from-purple-600 to-black border border-purple-500 rounded-full p-3 hover:from-purple-700 hover:to-purple-900 transition-colors shadow-lg shadow-purple-500/50"
          title="Panel de Administración"
        >
          <Settings className="w-6 h-6 text-white" />
        </button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {currentPage === 'login' && <LoginScreen />}
      {currentPage === 'home' && <HomeScreen />}
      {currentPage === 'clubs' && <ClubsScreen />}
      {currentPage === 'chats' && <ChatsScreen />}
      {currentPage === 'users' && <UsersScreen />}
      {currentPage === 'profile' && <ProfileScreen />}
      
      <NavigationBar />
      <CreateButton />
      <AdminButton />
      <AdminPanel />
      <UserActionsModal />
      <ShopModal />
    </div>
  );
}

export default SocialPlanet;
